/* This file will not be installed if not using gnu getopt. */

#include <bits/getopt.h>

