#ifndef __MONITOR_H__
#define __MONITOR_H__

enum { STOP, RUNNING, END };
extern int nemu_state;

#endif
