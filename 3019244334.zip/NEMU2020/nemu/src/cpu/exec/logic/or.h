#ifndef __OR_H__
#define __OR_H__

make_helper(or_i2a_b);
make_helper(or_i2rm_b);
make_helper(or_r2rm_b);
make_helper(or_rm2r_b);

make_helper(or_i2a_v);
make_helper(or_i2rm_v);
make_helper(or_si2rm_v);
make_helper(or_r2rm_v);
make_helper(or_rm2r_v);

#endif
