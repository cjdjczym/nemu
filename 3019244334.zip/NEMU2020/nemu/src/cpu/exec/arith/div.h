#ifndef __DIV_H__
#define __DIV_H__

make_helper(div_rm_b);

make_helper(div_rm_v);

#endif
