#ifndef __MUL_H__
#define __MUL_H__

make_helper(mul_rm_b);

make_helper(mul_rm_v);

#endif
