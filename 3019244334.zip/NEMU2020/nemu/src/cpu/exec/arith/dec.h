#ifndef __DEC_H__
#define __DEC_H__

make_helper(dec_rm_b);

make_helper(dec_rm_v);
make_helper(dec_r_v);

#endif
